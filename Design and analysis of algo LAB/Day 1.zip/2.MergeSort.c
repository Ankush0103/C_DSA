// Day 1 MergeSort
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

// We first write program for merge sort.
 void merge(int arr[],  int mid, int low, int high){
     int i, j, k, n, B[100];
     i = low;
     j = mid + 1;
     k = low;

     while(i<mid+1 && j<high+1){ // while(i<=mid && j<=high)
         if(arr[i]<arr[j]){
             B[k] = arr[i];
             i++;
             k++;
         }
         else{
             B[k] = arr[j];
             j++;
             k++;
         }
     }
     while(i<=mid){ // Copying elements of left array to the sorted array.
         B[k] = arr[i];
         k++;
         i++;
     }

     while(j<=high){ // Copying elements of right array to the sorted array.
         B[k] = arr[j];
         k++;
         j++;
     }
     for(int i = low; i <= high; i++){ // Copying element from sorted to main array(B array to given array)
         arr[i] = B[i];
     }
}

void mergeSort(int arr[], int low, int high){
    int mid;
    if(low<high){
        mid = (high + low)/2;
        mergeSort(arr, low, mid);
        mergeSort(arr, mid+1, high);
        merge(arr, mid, low, high);
    }
}

int main(){
    int n;
    int i;
    printf("Enter size of array: \n");
    scanf("%d", &n);
    int *arr = (int *)malloc(n*sizeof(int));    
    for(i=0; i<n; i++){
        printf("Enter the array %dth index integers: \n", i);
        scanf("%d", &arr[i]);
    }

    printf("Displaying unsorted Array: \n");
    for(i=0; i<n; i++){
        printf("%d  ", arr[i]);
    }
    printf("\n");

    mergeSort(arr, 0, n-1);
    printf("Printing the merge sorted array\n");
    for(i = 0; i<n; i++){
        printf("%d  ", arr[i]);       
    }
    printf("\n\n");
    return 0;

}
